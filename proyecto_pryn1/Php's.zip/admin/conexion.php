<?php

$connect = new mysqli("localhost","root","","login");

if($connect){
	 
}else{
	echo "Fallo, revise ip o firewall";
	exit();
}