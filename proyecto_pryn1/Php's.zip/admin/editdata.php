<?php

	include 'conexion.php';
	
	$id = $_POST['id'];

	$puntajeEval1 = $_POST['puntajeEval1'];
	$puntajeEval2 = $_POST['puntajeEval2'];
	$puntajeEval3 = $_POST['puntajeEval3'];
	$puntajeEval4 = $_POST['puntajeEval4'];
	$puntajeEval5 = $_POST['puntajeEval5'];
	
	$puntajeTotal = $_POST['puntajeEval1']/5 + $_POST['puntajeEval2']/5 +  $_POST['puntajeEval3']/5 + $_POST['puntajeEval4']/5 + $_POST['puntajeEval5']/5;

	
	$connect->query("UPDATE proyecto SET puntajeEval1='".$puntajeEval1."', puntajeEval2='".$puntajeEval2."', puntajeEval3='".$puntajeEval3."', puntajeEval4='".$puntajeEval4."', puntajeEval5='".$puntajeEval5."', puntajeTotal='".$puntajeTotal."' WHERE id=". $id);

?>