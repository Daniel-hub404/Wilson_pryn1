<?php

	include 'conexion.php';
	
	$id = $_POST['id'];

	$puntajeEval3 = $_POST['puntajeEval3'];

	
	$connect->query("UPDATE proyecto SET puntajeEval3='".$puntajeEval3."' WHERE id=". $id);

?>