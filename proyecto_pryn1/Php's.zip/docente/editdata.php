<?php

	include 'conexion.php';
	
	$id = $_POST['id'];

	$puntajeEval1 = $_POST['puntajeEval1'];

	
	$connect->query("UPDATE proyecto SET puntajeEval1='".$puntajeEval1."' WHERE id=". $id);

?>