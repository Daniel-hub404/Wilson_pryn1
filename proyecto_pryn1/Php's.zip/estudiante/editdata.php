<?php

	include 'conexion.php';
	
	$id = $_POST['id'];

	$puntajeEval2 = $_POST['puntajeEval2'];

	
	$connect->query("UPDATE proyecto SET puntajeEval2='".$puntajeEval2."' WHERE id=". $id);

?>